#/pack1_other
def gopFunc(a,b):
    return a*b
