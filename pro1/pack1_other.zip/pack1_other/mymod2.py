#/pack1_other
def hapHunc(a,b):
    return a+b

def chaFunc(a,b):
    return a-b