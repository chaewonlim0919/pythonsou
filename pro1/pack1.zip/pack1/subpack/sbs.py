#pack1/subpack/sbs #프로젝트 내에서만 공유 가능/ 
def sbsMansae():
    print('에스비에스 만세') 