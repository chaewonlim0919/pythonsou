#pack1/mymod1
tot = 100 #전역변수

def listHap(*ar):
    print(ar)
    if __name__ == '__main__':
        print('나는 메일모듈~~~~') #python ex15module.py으로 실행시킬 경우, 조건이 False이므로 출력X

def kbs():
    print('대한민국 대표방송')

def mbc():
    print('문화방송')